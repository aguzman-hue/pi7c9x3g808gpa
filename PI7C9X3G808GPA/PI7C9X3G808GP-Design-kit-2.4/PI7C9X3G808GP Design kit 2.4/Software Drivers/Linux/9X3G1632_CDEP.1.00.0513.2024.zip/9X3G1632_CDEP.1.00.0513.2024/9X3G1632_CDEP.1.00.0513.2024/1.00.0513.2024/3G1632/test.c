

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <linux/ioctl.h>
#include <pci/pci.h>



typedef struct _tagPSC_PARAMS_
{
    unsigned int offset;
    unsigned int size;
    unsigned long buffer;
} PSC_PARAMS, *PPSC_PARAMS;


#define PSC_IOCTL_CODE_BASE      0x0
#define IOCTL_MSG( code )        _IOWR('D', code, PSC_PARAMS )




typedef enum _DRIVER_MSGS
{
    MSG_BAR2_READ = PSC_IOCTL_CODE_BASE,
    MSG_BAR2_WRITE,
    MSG_BAR4_READ,
    MSG_BAR4_WRITE
} DRIVER_MSGS;

#define PSC_IOCTL_BAR2_READ		IOCTL_MSG( MSG_BAR2_READ )
#define PSC_IOCTL_BAR2_WRITE		IOCTL_MSG( MSG_BAR2_WRITE )
#define PSC_IOCTL_BAR4_READ		IOCTL_MSG( MSG_BAR4_READ )
#define PSC_IOCTL_BAR4_WRITE		IOCTL_MSG( MSG_BAR4_WRITE )




#define IOCTL_TX_TEST _IOWR(0x66, 1, TEST_PARAMETER)
#define IOCTL_ALLOC_BUFFER _IOWR(0x66, 2, TEST_PARAMETER)



int main(int argc, char** argv)
{


	int devfile = -1;
	int nStatus = 0;
	void *pBuffer = 0;

	unsigned long long value = 0;

	int sym_id = 0;


	char buffer[80];
	PSC_PARAMS param;


	memset(&param, 0, sizeof(param));

	param.offset = 0;
	param.size = 1;
	param.buffer = (unsigned long)buffer;


	sprintf(buffer, "/dev/CDEP_%d", sym_id);
	devfile = open(buffer, O_RDWR);

	if (devfile < 0) {

		perror("open");
		exit(-1);

	} else {

		printf("Write BAR2 0x5A\n");
		buffer[0] = 0x5A;

		nStatus = ioctl(devfile, PSC_IOCTL_BAR2_WRITE, &param);
		if (nStatus < 0) {
			printf("ioctl PSC_IOCTL_BAR2_WRITE fail\n");
			return 0;
		}

		buffer[0] = 0;
		printf("clear buffer\n");

		param.offset = 0;
		param.size = 1;
		param.buffer = (unsigned long)buffer;

		printf("Read BAR2...");
		nStatus = ioctl(devfile, PSC_IOCTL_BAR2_READ, &param);
		if (nStatus < 0) {
			printf("ioctl PSC_IOCTL_BAR2_READ fail\n");
			return 0;
		}

		printf("%02X\n", buffer[0]);

		printf("Write BAR4 0xA5\n");
		buffer[0] = 0xA5;

		nStatus = ioctl(devfile, PSC_IOCTL_BAR4_WRITE, &param);
		if (nStatus < 0) {
			printf("ioctl PSC_IOCTL_BAR4_WRITE fail\n");
			return 0;
		}

		printf("clear buffer\n");
		buffer[0] = 0;

		printf("Read BAR4...");
		nStatus = ioctl(devfile, PSC_IOCTL_BAR4_READ, &param);
		if (nStatus < 0) {
			printf("ioctl PSC_IOCTL_BAR4_READ fail\n");
			return 0;
		}

		printf("%02X\n", buffer[0]);



		close(devfile);
		printf("OK\n");
	}




	return 0;
}
