

#ifndef _PSCTYPE_H_
#define _PSCTYPE_H_



// windows
typedef signed char             S8;
typedef unsigned char           U8;
typedef signed short            S16;
typedef unsigned short          U16;
typedef signed long             S32;
typedef unsigned int            U32;
typedef signed long long        S64;
typedef unsigned long long      U64;


typedef signed char *           PS8;
typedef unsigned char *         PU8;
typedef signed short *          PS16;
typedef unsigned short *        PU16;
typedef signed long *           PS32;
typedef unsigned long *         PU32;
typedef signed long long *      PS64;
typedef unsigned long long *    PU64;


typedef void * 			HANDLE;
typedef int *			INT_PTR;
//typedef unsigned int *		UINT_PTR;
typedef unsigned long 		UINT_PTR;
typedef void 			VOID;
typedef bool			BOOLEAN;
typedef struct list_head 	LIST_ENTRY;
typedef spinlock_t		KSPIN_LOCK;


typedef HANDLE                  PSC_HANDLE;
//typedef U32                     PSC_STATUS;
typedef INT_PTR               	PSC_INT_PTR;        // For 32/64-bit code compatability
typedef UINT_PTR              	PSC_UINT_PTR;

#define PSC_INT_TO_PTR( int )                     ((VOID*)(PSC_UINT_PTR)(int))
#define PSC_CAST_64_TO_8_PTR( ptr64 )     (U8*) (ptr64)
#define PSC_CAST_64_TO_16_PTR( ptr64 )    (U16*)(ptr64)
#define PSC_CAST_64_TO_32_PTR( ptr64 )    (U32*)(ptr64)


#define PSC_64_HIGH_32(value)             ((U32)(((U64)value) >> 32))
#define PSC_64_LOW_32(value)              ((U32)((U64)value))
#define PSC_LE_U32_BIT( pos )             ((U32)(1 << (pos)))
#define PSC_LE_DATA_32(value)                 (value)


#define PCI_FIELD_IGNORE 		(-1)

#if 1

#define PSC_STATUS_START        0x100


#define MAX_MDL_SIZE                        (PAGE_SIZE * ((65535 - sizeof(MDL)) / sizeof(PU32))) - (1 << 21)
#define MAX_VIRTUAL_ADDR                    10      // Max number of virtual addresses for a space
#define PHYS_MEM_MAX_SIZE_ALL               (100 << 20)     // Max total allowable size of physically memory to allocate

//#define PORT_TYPE_NONE											0
//#define PORT_TYPE_NT_VIRTUAL  									1
//#define PORT_TYPE_NT_LINK										2


#define DEVICE_TYPE_NONE										0
#define DEVICE_TYPE_NT_VIRTUAL  								1
#define DEVICE_TYPE_NT_LINK										2
#define DEVICE_TYPE_DMA_VIRTUAL  								3
#define DEVICE_TYPE_DMA_LINK									4


typedef struct _tagPSC_DEVICE_KEY_
{
		U32	PciAddress;
		U32 DeviceNumber;
		//U32 PortType;
		U32 DeviceType;
	
} PSC_DEVICE_KEY, *PPSC_DEVICE_KEY;





// PCI BAR Properties
typedef struct _tagPCI_BAR_PROP_
{
    U32 BarValue;                    // Actual value in BAR
    U64 Physical;                    // BAR Physical Address
    U64 Size;                        // Size of BAR space
    U8  bPrefetchable;               // Is space pre-fetchable?
//    U8  bIoSpace;                    // Memory or I/O space?    
//    U8  b64bit;                      // Is PCI BAR 64-bit?
} PCI_BAR_PROP, *PPCI_BAR_PROP;
		
		
		
		
		
// PCI BAR Space information
typedef struct _tagPCI_BAR_INFO_
{
    
    PCI_BAR_PROP        Properties;               // BAR Properties
    PU8                 pVa;                      // BAR Kernel Virtual Address
    //PMDL                pMdl;                     // MDL for the BAR space
} PCI_BAR_INFO, *PPCI_BAR_INFO;		
		
#define PCI_NUM_BARS_TYPE_00 6		
		
		





// Mappings to user virtual space
typedef struct _tagUSER_MAPPING_
{
    LIST_ENTRY  ListEntry;
    VOID       *pOwner;
    U8          BarIndex;
    VOID       *pUserVa[MAX_VIRTUAL_ADDR];
} USER_MAPPING, *PUSER_MAPPING;




// PCI Memory Structure
typedef struct _tagPHYSICAL_MEM_
{
    U64 UserAddr;                    // User-mode virtual address
    U64 PhysicalAddr;                // Bus physical address
    U64 CpuPhysical;                 // CPU physical address
    U32 Size;                        // Size of the buffer
} PHYSICAL_MEM, *PPHYSICAL_MEM;

// Information about contiguous, page-locked buffers
typedef struct _tagPHYS_MEM_OBJECT_
{
    LIST_ENTRY   ListEntry;
    VOID        *pOwner;
    VOID        *pKernelVa;
    U64          CpuPhysical;                   // CPU Physical Address
    U64          BusPhysical;                   // Bus Physical Address
    U32          Size;                          // Buffer size
    //PMDL         pMdl;
    BOOLEAN      bCacheable;
    LIST_ENTRY   List_Mappings;                 // List of mappings for this physical memory
    KSPIN_LOCK   Lock_MappingsList;             // Spinlock for mappings list
} PHYS_MEM_OBJECT, *PPHYS_MEM_OBJECT;


typedef struct _PSC_NOTIFY_OBJECT
{

    U64 pWaitObject;                 // -- INTERNAL -- Wait object used by the driver
    U64 hEvent;                      // User event handle (HANDLE can be 32 or 64 bit)
} PSC_NOTIFY_OBJECT;



typedef struct _PSC_INTERRUPT
{
    U32 Doorbell;                    // Up to 32 doorbells
    
  	union {
	  	struct {
	  		U64 _0				: 8;
	  		U64 _1				: 8;
			U64 _2				: 8;
			U64 _3				: 8;
			U64 _4				: 8;
			U64 _5				: 8;
			U64 _6				: 8;
			U64 _7				: 8;  			  		
		} ch;
		U64 x;
		
  	} DMA;
    
/*    
    U32  DmaDone                :4;   // DMA channel 0-3 interrupts
    U32  DmaPauseDone           :4;
    U32  DmaAbortDone           :4;
    U32  DmaImmedStopDone       :4;
    	
    U32  DmaInvalidDescr        :4;
    U32  DmaError               :4;    
*/    
} PSC_INTERRUPT;

struct _tagPSCGRANDE_DRIVER_DATA ;

typedef struct _PSC_REG_DATA
{
    struct _tagPSCGRANDE_DRIVER_DATA   		      *FdoData;
    U32                       offset;
    U32                       BitsToSet;
    U32                       BitsToClear;
} PSC_REG_DATA;


typedef struct _PSC_INTERRUPT_DATA
{
    struct _tagPSCGRANDE_DRIVER_DATA  		     *FdoData;   
    U64                       Source_Ints;
    U32                       Source_Doorbell;
} PSC_INTERRUPT_DATA;







// PCI Interrupt wait object
typedef struct _PSC_WAIT_OBJECT
{
    LIST_ENTRY  ListEntry;
    VOID       *pOwner;
    U64         Notify_Flags;                   // Registered interrupt(s) for notification
    U32         Notify_Doorbell;                // Registered doorbell interrupt(s) for notification
    U64         Source_Ints;                    // Interrupt(s) that caused notification
    U32         Source_Doorbell;                // Doorbells that caused notification
    wait_queue_head_t WaitQueue;
    atomic_t	SleepCount;
    U32		State;
} PSC_WAIT_OBJECT;





#define AT_GROUP_BAR_2 0
#define AT_GROUP_BAR_3 1
#define AT_GROUP_BAR_4 2
#define AT_GROUP_BAR_5 4

#define AT_MODE_DAT 0
#define AT_MODE_LUT 1


typedef struct _CDEP_AT_PROP_ {
	U8 bMode;
	U8 b64bit;
	U8 bPrefetchable;
	U8 bPartition;
	U64 Size;	
} CDEP_AT_PROP, *PCDEP_AT_PROP;





#define NUM_OF_DESC			4096
#pragma pack(1)
/*
typedef struct _tagPSC_DMA_DESC_ 
{
	U32		count 	: 24;
	U32		rerv0 	: 3;
	U32		dav		: 1;
	U32		sav		: 1;
	U32		rerv1	: 1;
	U32		intr	: 1;
	U32		eot		: 1;
	//U64		da;
	U32		da;
	//U64		sa;		
	U32		sa;		
	
} PSC_DMA_DESC, *PPSC_DMA_DESC;
*/

typedef struct _tagPSC_DMA_DESC_ 
{
	U32		reserv0 	: 21;
	U32		ctrl_crc	: 1;	
	U32		ctrl_ddv	: 1;
	U32		ctrl_sdv	: 1;
	U32		ctrl_bit64	: 1;			
	U32		ctrl_dav	: 1;
	U32		ctrl_sav	: 1;
	U32		ctrl_flh	: 1;
	U32		ctrl_nop	: 1;
	U32		ctrl_tph	: 1;	
	U32		ctrl_intr	: 1;
	U32		ctrl_eot	: 1;
		
	U32		count 		: 24;
	U32		reserv1 	: 8;		
		
	U32		hda;
	U32		lda;
	U32		hsa;		
	U32		lsa;	
	
	U32		dd 			: 8;
	U32		sd			: 8;
	U32		reserv2 	: 16;
		
	U32		crc;
	
} PSC_DMA_DESC, *PPSC_DMA_DESC;




#pragma pack()




// DMA Channel Properties Structure
typedef struct _PSC_DMA_PROP
{
  	    	
	U8  DoneInterrupt       :1;    	
	U8  PauseInterrupt      :1;    	
	U8	AbortInterrupt		:1;
    U8  EnableEOT           :1;   	   	
    U8  ChannelMappingEnable:1;    	    	
    U8  ChannelCount		:3;
    
    U8	ChannelMappingPeer  :3;
    	    
    	    
	U8  MaxTotalDescriptorCount;    		
	U8  MaxChannelDescriptorCount;    		       		
    
    U32 MaxSizePerDescriptor;
        	
} PSC_DMA_PROP;


// DMA Transfer Parameters
typedef struct _PSC_DMA_PARAMS
{
    U64 UserVa;                     // User buffer virtual address
    U64 AddrSource;                 // Source address      
    U64 AddrDest;                   // Destination address 
    U64 PciAddr;                    // PCI address         
    U32 LocalAddr;                  // Local bus address   
    U32 ByteCount;                  // Number of bytes to transfer
    U32 PartitionSource;			
    U32 PartitionDest;			
    
    
    U8  Direction;                  // Direction of transfer (Local<->PCI, User<->PCI)
    U8  bConstAddrSrc   :1;         // Constant source PCI address?      
    U8  bConstAddrDest  :1;         // Constant destination PCI address? 
    U8  bForceFlush     :1;         // Force DMA to flush write on final descriptor 
    U8  bIgnoreBlockInt :1;         // For block mode only, do not enable DMA done interrupt
} PSC_DMA_PARAMS;



// DMA control commands
typedef enum _PSC_DMA_COMMAND
{
    DmaPause,
    DmaPauseImmediate,
    DmaResume,
    DmaAbort,
    DmaIPC,		
    DmaLocal
} PSC_DMA_COMMAND;

// DMA Descriptor Mode
typedef enum _PSC_DMA_DESCR_MODE
{
    PSC_DMA_MODE_BLOCK         = 0,                      // DMA Block transfer mode
    PSC_DMA_MODE_SGL           = 1,                      // DMA SGL with descriptors off-chip
    PSC_DMA_MODE_SGL_INTERNAL  = 2                       // DMA SGL with descriptors on-chip
} PSC_DMA_DESCR_MODE;

// DMA transfer direction
typedef enum _PSC_DMA_DIR
{
    PSC_DMA_PCI_TO_LOC         = 0,                       // DMA PCI --> Local bus   
    PSC_DMA_LOC_TO_PCI         = 1,                       // DMA Local bus --> PCI   
    PSC_DMA_USER_TO_PCI        = PSC_DMA_PCI_TO_LOC,      // DMA User buffer --> PCI 
    PSC_DMA_PCI_TO_USER        = PSC_DMA_LOC_TO_PCI       // DMA PCI --> User buffer 
} PSC_DMA_DIR;


// Non-transparent LUT flags
typedef enum _tarNT_LUT_FLAG_
{
    PSC_NT_LUT_FLAG_NONE        = 0,
    PSC_NT_LUT_FLAG_NO_SNOOP    = (1 << 0),
    PSC_NT_LUT_FLAG_READ        = (1 << 1),
    PSC_NT_LUT_FLAG_WRITE       = (1 << 2)
} PSC_NT_LUT_FLAG;

		
typedef enum _tarWAIT_OBJECT_STATE_
{
	PSC_WAIT_OBJECT_STATE_WAITING = 1,
	PSC_WAIT_OBJECT_STATE_TRIGGERED,
	PSC_WAIT_OBJECT_STATE_MARKED_FOR_DELETE

} WAIT_OBJECT_STATE;

		

// API Return Code Values
typedef enum _tagPSC_STATUS_
{
    ApiSuccess = PSC_STATUS_START,
    ApiFailed,
    ApiNullParam,
    ApiUnsupportedFunction,
    ApiNoActiveDriver,
    ApiConfigAccessFailed,
    ApiInvalidDeviceInfo,
    ApiInvalidDriverVersion,
    ApiInvalidOffset,
    ApiInvalidData,
    ApiInvalidSize,
    ApiInvalidAddress,
    ApiInvalidAccessType,
    ApiInvalidIndex,
    ApiInvalidPowerState,
    ApiInvalidIopSpace,
    ApiInvalidHandle,
    ApiInvalidPciSpace,
    ApiInvalidBusIndex,
    ApiInsufficientResources,
    ApiWaitTimeout,
    ApiWaitCanceled,
    ApiDmaChannelUnavailable,
    ApiDmaChannelInvalid,
    ApiDmaDone,
    ApiDmaPaused,
    ApiDmaAbort,
    ApiDmaInProgress,
    ApiDmaCommandInvalid,
    ApiDmaInvalidChannelPriority,
    ApiDmaSglPagesGetError,
    ApiDmaSglPagesLockError,
    ApiMuFifoEmpty,
    ApiMuFifoFull,
    ApiPowerDown,
    ApiHSNotSupported,
    ApiVPDNotSupported,
    ApiDeviceInUse,
    ApiDeviceDisabled,
    ApiPending,
    ApiObjectNotFound,
    ApiInvalidState,
    ApiBufferTooSmall,
    ApiLastError               // Do not add API errors below this line
} PSC_STATUS;




typedef BOOLEAN (KSYNCHRONIZE_ROUTINE)( PSC_REG_DATA *pRegData );
typedef KSYNCHRONIZE_ROUTINE *PKSYNCHRONIZE_ROUTINE;


#endif


#endif







