

#ifndef _DRIVER_H_
#define _DRIVER_H_


#include "psctype.h"



#define MAX_NUM_OF_DEVICE	16

#define MAX_NUM_OF_CDEP		12
#define MAX_NUM_OF_TILE		6

#define INTR_TYPE_NONE                  0              // Interrupt identifiers


#define STATUS_SUCCESS 0


#define MAX_NAME_LENGTH   64
#define MAX_NUM_OF_DEVICE	16


#define MAX_NUM_OF_CHANNEL	4

#define MAX_NUM_OF_DMA_DESC	4096 //64

typedef void *PMDL;
typedef PU32 PULONG;
typedef int NTSTATUS;

typedef struct _tagPSC_DMA_INFO_
{
	U64					pdesc_ph;
	PPSC_DMA_DESC		pdesc_va;
	U32					count;
	U32					next;
	U64					base_addr;
	
	U32                 Source_Ints;                    // Interrupts detected by ISR
	
    VOID                *pOwner;                // Object that requested to open the channel
    PMDL                 pMdl;                  // MDL of the user buffer for locking and unlocking
    PHYS_MEM_OBJECT  	SglBuffer;             // Current SGL descriptor list buffer	
    BOOLEAN              bOpen;                 // Flag to note if DMA channel is open
    BOOLEAN              bSglPending;           // Flag to note if an SGL DMA is pending
    
    
} PSC_DMA_INFO, *PPSC_DMA_INFO;



#define DMA_CSR_CTRL_STATUS_0			0x00
#define DMA_CSR_DESC_OWN_0				0x04
#define DMA_CSR_DESC_OWN_1				0x08

#define DMA_CSR_DESC_BASE_LOW			0x0C  	//0x24
#define DMA_CSR_DESC_BASE_HIGH			0x10	//0x28
#define DMA_CSR_DESC_CURRENT_PTR 		0x14	//0x2C
#define DMA_CSR_DESC_CURRENT_STATUS		0x18	//0x30
#define DMA_CSR_FETCH_GAP_TIME			0x1C
#define DMA_CSR_CTRL_STATUS_1			0x20
#define DMA_CSR_FETCH_LIMIT				0x24
#define DMA_CSR_MAX_SIZE_PARTITION_0_3	0x28
#define DMA_CSR_MAX_SIZE_PARTITION_4_7	0x2C
#define DMA_CSR_MAX_SIZE_PARTITION_8_11	0x30
#define DMA_CSR_BUS_NUM_PARTITION_0_3	0x34
#define DMA_CSR_BUS_NUM_PARTITION_4_7	0x38
#define DMA_CSR_BUS_NUM_PARTITION_8_11	0x3C


#define DMA_CSR_USER_DEFINED_ATTRIBUTES 0x40
#define DMA_CSR_CHANNEL_UNCORRECTABLE_ERROR_STATUS 	0x44
#define DMA_CSR_READ_THREADOLD_CONTROL	0x5C



//#define DMA_CSR_MODE					0x44  	// Bit 21-20  	CD mode
												// Bit 19-18  	DMA mode
												// Bit 17		Master Tile
												
//#define DMA_MODE_ALL					0			
//#define DMA_MODE_SEPERATION				0x0001
//#define DMA_MODE_CDEP_EXIST				0x0002
//#define DMA_MODE_MASTER_TILE			0x0004
#define DMA_MODE_NONE					0
#define DMA_MODE_R2						2
#define DMA_MODE_R3						3
#define DMA_MODE_R5						5
#define DMA_MODE_R6						6
#define DMA_MODE_R7						7
#define DMA_MODE_R8						8
#define DMA_MODE_R9						9
#define DMA_MODE_R10					10





#define DMA_MODE_ALL_OFFSET_STEP		0x100
#define DMA_MODE_SEPERATION_OFFSET_STEP	0x400







typedef struct _tagPSCGRANDE_DRIVER_DATA {
	struct list_head list;

	struct pci_dev *pdev;

	struct device *pdevice;
	struct cdev 	chr_dev;
	dev_t xDeviceNo;


	U32 		ulPciAddress;
	
	U32 		ReqID;
	PSC_DEVICE_KEY	Key;

	bool primary;
	bool isDMA;
	int nDeviceIndex;

	char devname[128];

	unsigned long xBar0PhysicalAddr;
	unsigned long xBar0VirtualAddr;
	unsigned long xBar0Length;


	unsigned long xBar2PhysicalAddr;
	unsigned long xBar2VirtualAddr;
	unsigned long xBar2Length;

	unsigned long xBar4PhysicalAddr;
	unsigned long xBar4VirtualAddr;
	unsigned long xBar4Length;


	int iPortNumber;
	int iTileNumber;
	int iDomainNumber;
	
	
	int iMemBasedCdepIndex;  //  p : port0 = 0; port4 = 1, t : tile  ==>  iMembasedCdepIndex = tile * 2 + p ===?  iMembasedCdepIndex = iTileNumber * 2 + (iPortNumber == 4) ? 1 : 0;
	unsigned int pMemBasedCdep[MAX_NUM_OF_CDEP]; //PU8 pMemBasedCdep[MAX_NUM_OF_CDEP];





	LIST_ENTRY          List_BarMappings;               // List of mappings to user space
    	KSPIN_LOCK          Lock_BarMappingsList;           // Spinlock for user mappings list

    	LIST_ENTRY          List_PhysicalMem;               // List of user-allocated physical memory
    	KSPIN_LOCK          Lock_PhysicalMemList;           // Spinlock for physical memory list

    	LIST_ENTRY          List_WaitObjects;               // List of registered notification objects
    	KSPIN_LOCK          Lock_WaitObjectsList;           // Spinlock for notification objects list	
	


	U32                 Source_Ints;                    // Interrupts detected by ISR
        U32                 Source_Doorbell;                // Doorbell interrupts detected by ISR
		
	// DMA
	
	U32					NumDmaChannels; 	
	U32 				modeDMA;
	U32 				offsetStepDMA;
	PSC_DMA_INFO		DMA[MAX_NUM_OF_CHANNEL];
	PSC_DMA_PROP 		DMAProp[MAX_NUM_OF_CHANNEL];
	KSPIN_LOCK          Lock_Dma[MAX_NUM_OF_CHANNEL];
	
	///////
	
	U32					PartitionMap;
	



	raw_spinlock_t	Lock_Interrupt;


	struct work_struct DpcForIsr; 	// for work_queue

	U32		isLink;
	U32		Order;

	U32		nBar2Offset;
	U32		nBar4Offset;

} /*PSCGRANDE_DRIVER_DATA, *PPSCGRANDE_DRIVER_DATA,*/ *PFDO_DEVICE_DATA, FDO_DEVICE_DATA;



#define RtlFillMemory(a, b, c)  memset(a, c, b)


#define RtlZeroMemory(a, b) memset(a, 0, b)




#define DebugPrintf printk






#endif











