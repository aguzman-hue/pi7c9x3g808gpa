
///////////////////////////////////////////////////////////////////////////////////
// uncommend one or two defines to enable the correct initialization as you want

#define ONE_TO_ONE_MAPPING_FIRST_PAIR
//#define ONE_TO_ONE_MAPPING_SECOND_PAIR
//
//#define THREE_NODES_CIRCLE
//#define FOUR_NODES_CIRCLE
//
///////////////////////////////////////////////////////////////////////////////////

#define DOMAIN_0	0
#define DOMAIN_1	1
#define DOMAIN_2	2
#define DOMAIN_3	3

///////////////////////////////////////////////////////////////////////////////////
// memory address (64bit width) for mapping to BAR2/BAR4
// 	..._1 : BAR2
// 	..._2 : BAR4
#define DOMAIN_0_MEM_PHYSICAL_ADDRESS_1	(unsigned long)0
#define DOMAIN_0_MEM_PHYSICAL_ADDRESS_2	(unsigned long)0

#define DOMAIN_1_MEM_PHYSICAL_ADDRESS_1	(unsigned long)0
#define DOMAIN_1_MEM_PHYSICAL_ADDRESS_2	(unsigned long)0

#define DOMAIN_2_MEM_PHYSICAL_ADDRESS_1	(unsigned long)0
#define DOMAIN_2_MEM_PHYSICAL_ADDRESS_2	(unsigned long)0

#define DOMAIN_3_MEM_PHYSICAL_ADDRESS_1	(unsigned long)0
#define DOMAIN_3_MEM_PHYSICAL_ADDRESS_2	(unsigned long)0


///////////////////////////////////////////////////////////////////////////////////
// device id
#define PSCGRANDE_DEVICE_ID 0xC232


///////////////////////////////////////////////////////////////////////////////////
#if defined(THREE_NODES_CIRCLE) 
#define NUM_OF_DOMAIN 3
#else
#define NUM_OF_DOMAIN 4
#endif
///////////////////////////////////////////////////////////////////////////////////

#include <linux/kernel.h>
#include <linux/pci.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include <linux/interrupt.h>
#include <linux/irqchip/chained_irq.h>
#include <linux/init.h>
#include <linux/of_irq.h>
#include <linux/of_address.h>
#include <linux/of_platform.h>
#include <linux/of_gpio.h>
#include <linux/of_pci.h>
#include <linux/platform_device.h>
#include <linux/module.h>
#include <linux/io.h>
#include <linux/delay.h>
#include <linux/slab.h>
#include <linux/version.h>
#include <linux/clk.h>
#include <linux/gpio.h>
#include <linux/phy/phy.h>
#include <linux/irqreturn.h>
#include <linux/fs.h>
#include <linux/signal.h>
#include <linux/cdev.h>
#include <linux/delay.h>
#include <linux/poll.h>
#include <linux/device.h>
#include <asm/uaccess.h>
#include <linux/sched.h>
#include <linux/kthread.h>
#include <linux/dma-mapping.h>
#include <linux/wait.h>
#include <linux/completion.h>
#include <linux/pci_regs.h>

#include "driver.h"


MODULE_LICENSE("GPL");
MODULE_AUTHOR("simoncc");


#define PSCGRANDE_VERSION	"1.00.0513.2024"


#define PSCGRANDE_NAME "psc1632"
#define PSCGRANDE_CDEP_DEVICE_NAME "cdep"
#define PSCGRANDE_VENDOR_ID 0x12D8

#define PSCGRANDE_DEVICE_ID_8608 0x8608
#define PSCGRANDE_CDEP_CLASS_ID 0x068000
#define PSCGRANDE_CLASS_MASK 0xffffff00


#define GET_DOMAIN_BASE(x,d)	((int)(x->pMemBasedCdep[d]))
#define MAGIC_NUMBER	(U32)((PSCGRANDE_DEVICE_ID << 16) | PSCGRANDE_VENDOR_ID)


typedef struct _tagPSC_PARAMS_
{
    U32 offset;
    U32 size;
    U64 buffer;
} PSC_PARAMS, *PPSC_PARAMS;


#define PSC_IOCTL_CODE_BASE      0x0
#define IOCTL_MSG( code )        _IOWR( 'D', code, PSC_PARAMS )




typedef enum _DRIVER_MSGS
{
    MSG_BAR2_READ = PSC_IOCTL_CODE_BASE,
    MSG_BAR2_WRITE,
    MSG_BAR4_READ,
    MSG_BAR4_WRITE
} DRIVER_MSGS;


#define PSC_IOCTL_BAR2_READ		IOCTL_MSG( MSG_BAR2_READ )
#define PSC_IOCTL_BAR2_WRITE		IOCTL_MSG( MSG_BAR2_WRITE )
#define PSC_IOCTL_BAR4_READ		IOCTL_MSG( MSG_BAR4_READ )
#define PSC_IOCTL_BAR4_WRITE		IOCTL_MSG( MSG_BAR4_WRITE )




static struct class * g_ppscgrande_class;
static dev_t xDeviceNo;
static int g_nDMAcount = 0;
static int g_nCDEPcount = 0;
static LIST_HEAD(g_pDevice);


void ScratchpadWrite(PFDO_DEVICE_DATA pdx, int nDomain, int nIndex, unsigned int nValue);
void ScratchpadRead(PFDO_DEVICE_DATA pdx, int nDomain, int nIndex, unsigned int *pnValue);
void DoorbellEnable(PFDO_DEVICE_DATA pdx, int nDomain, unsigned int nMask);
void DoorbellDisable(PFDO_DEVICE_DATA pdx, int nDomain, unsigned int nMask);
void DoorbellTrigger(PFDO_DEVICE_DATA pdx, int nDomain, unsigned int nMask);
unsigned int DoorbellStatus(PFDO_DEVICE_DATA pdx, int nDomain);
void InitDAT(PFDO_DEVICE_DATA pdx, int nMyDomain, int nTargetDomain, bool fBAR4, unsigned int nMemPhysicalAddress_Upper, unsigned int nMemPhysicalAddress_Lower);




int pscgrande_cdep_open(struct inode * inode, struct file * file)
{
	PFDO_DEVICE_DATA pdx;

	pdx = container_of(inode->i_cdev, FDO_DEVICE_DATA, chr_dev);
	printk( KERN_NOTICE "pscgrande: pscgrande_cdep_open  %p\n", pdx );
	file->private_data = pdx;

	return 0;
}




int pscgrande_cdep_close(struct inode * inode, struct file * file)
{

	return 0;
}




long pscgrande_cdep_unlocked_ioctl(struct file * file, unsigned int cmd, unsigned long arg)
{
	PFDO_DEVICE_DATA pdx = file->private_data;

	PSC_PARAMS IoBuffer;
	VOID *pOwner;
	int status;

	printk(KERN_ALERT "%s(%d): pscgrande_unlocked_ioctl cmd = %08x\n", __func__, __LINE__, cmd);

	status = copy_from_user(&IoBuffer, (void *)arg, sizeof(PSC_PARAMS));
	if (status != 0) {

		return (-EFAULT);
	}

	pOwner = file;

	switch(cmd) {

	case PSC_IOCTL_BAR2_READ:
		status = copy_to_user((void *)IoBuffer.buffer, (void*)(((PU8)pdx->xBar2VirtualAddr) + pdx->nBar2Offset + IoBuffer.offset), IoBuffer.size);
		break;

	case PSC_IOCTL_BAR2_WRITE:
		status = copy_from_user( (void*)(((PU8)pdx->xBar2VirtualAddr) + pdx->nBar2Offset + IoBuffer.offset), (void *)IoBuffer.buffer, IoBuffer.size);
		break;

	case PSC_IOCTL_BAR4_READ:
		status = copy_to_user((void *)IoBuffer.buffer, (void*)(((PU8)pdx->xBar4VirtualAddr) + IoBuffer.offset), IoBuffer.size);
		break;


	case PSC_IOCTL_BAR4_WRITE:
		status = copy_from_user( (void*)(((PU8)pdx->xBar4VirtualAddr) + IoBuffer.offset), (void *)IoBuffer.buffer, IoBuffer.size);
		break;
		
	default:
		printk(KERN_ALERT "%s(%d): pscgrande_unlocked_ioctl cmd = INVALID\n", __func__, __LINE__);
		return -EINVAL;

	}


	

	return 0;
}


static struct file_operations pscgrande_cdep_fops = {
		.owner = THIS_MODULE,
		.open = pscgrande_cdep_open,
		.release = pscgrande_cdep_close,
		.unlocked_ioctl = pscgrande_cdep_unlocked_ioctl,
};



irqreturn_t pscgrande_cdep_interrupt(int irq, void * dev)
{
	PFDO_DEVICE_DATA pdx = (PFDO_DEVICE_DATA)dev;
	U32 nValue = 0;
	U32 nMemPhysicalAddress_Upper = 0;
	U32 nMemPhysicalAddress_Lower = 0;


#ifdef ONE_TO_ONE_MAPPING_FIRST_PAIR
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	// 1 pair 1-to-1 mapping (domain 0 <-> domain 1)
	if (pdx->iDomainNumber == DOMAIN_0) {
		// domain 1 knocked my door
		nValue = DoorbellStatus(pdx, DOMAIN_0);
			
		if ((nValue & 0x8000) == 0x8000) {

			ScratchpadRead(pdx, DOMAIN_1, 5, &nMemPhysicalAddress_Upper); 
			ScratchpadRead(pdx, DOMAIN_1, 4, &nMemPhysicalAddress_Lower); 	
			InitDAT(pdx, DOMAIN_0, DOMAIN_1, false, nMemPhysicalAddress_Upper, nMemPhysicalAddress_Lower); 

			ScratchpadRead(pdx, DOMAIN_1, 7, &nMemPhysicalAddress_Upper); 
			ScratchpadRead(pdx, DOMAIN_1, 6, &nMemPhysicalAddress_Lower); 	
			InitDAT(pdx, DOMAIN_0, DOMAIN_1, true, nMemPhysicalAddress_Upper, nMemPhysicalAddress_Lower); 

			//check whether i have the magic_number or not
			ScratchpadRead(pdx, DOMAIN_0, 0, &nValue); 		
					
			if (nValue == MAGIC_NUMBER) {
				// clear MAGIC_NUMBER
				ScratchpadWrite(pdx, DOMAIN_0, 0, 0); 
						
				// fill my info
				ScratchpadWrite(pdx, DOMAIN_0, 4, DOMAIN_0_MEM_PHYSICAL_ADDRESS_1 & 0xFFFFFFFF); 
				ScratchpadWrite(pdx, DOMAIN_0, 5, (DOMAIN_0_MEM_PHYSICAL_ADDRESS_1 >> 32) & 0xFFFFFFFF); 
				ScratchpadWrite(pdx, DOMAIN_0, 6, DOMAIN_0_MEM_PHYSICAL_ADDRESS_2 & 0xFFFFFFFF); 
				ScratchpadWrite(pdx, DOMAIN_0, 7, (DOMAIN_0_MEM_PHYSICAL_ADDRESS_2 >> 32) & 0xFFFFFFFF); 
					
				// knock domain 1's door to get domain 0's info (in ISR)
				DoorbellTrigger(pdx, DOMAIN_1, 0x8000); 
			}
					
			// Disable my doorbell
			DoorbellDisable(pdx, DOMAIN_0, 0x8000);
		}			
	} else if (pdx->iDomainNumber == DOMAIN_1) {
		// domain 0 knocked my door
		nValue = DoorbellStatus(pdx, DOMAIN_1);
			
		if ((nValue & 0x8000) == 0x8000) {

			ScratchpadRead(pdx, DOMAIN_0, 5, &nMemPhysicalAddress_Upper); 
			ScratchpadRead(pdx, DOMAIN_0, 4, &nMemPhysicalAddress_Lower); 	
			InitDAT(pdx, DOMAIN_1, DOMAIN_0, false, nMemPhysicalAddress_Upper, nMemPhysicalAddress_Lower); 

			ScratchpadRead(pdx, DOMAIN_0, 7, &nMemPhysicalAddress_Upper); 
			ScratchpadRead(pdx, DOMAIN_0, 6, &nMemPhysicalAddress_Lower); 	
			InitDAT(pdx, DOMAIN_1, DOMAIN_0, true, nMemPhysicalAddress_Upper, nMemPhysicalAddress_Lower); 
				
			//check whether i have the magic_number or not	
			ScratchpadRead(pdx, DOMAIN_1, 0, &nValue); 	

			if (nValue == MAGIC_NUMBER) {
				// clear MAGIC_NUMBER
				ScratchpadWrite(pdx, DOMAIN_1, 0, 0); 
					
				// fill my info
				ScratchpadWrite(pdx, DOMAIN_1, 4, DOMAIN_1_MEM_PHYSICAL_ADDRESS_1 & 0xFFFFFFFF); 
				ScratchpadWrite(pdx, DOMAIN_1, 5, (DOMAIN_1_MEM_PHYSICAL_ADDRESS_1 >> 32) & 0xFFFFFFFF); 
				ScratchpadWrite(pdx, DOMAIN_1, 6, DOMAIN_1_MEM_PHYSICAL_ADDRESS_2 & 0xFFFFFFFF); 
				ScratchpadWrite(pdx, DOMAIN_1, 7, (DOMAIN_1_MEM_PHYSICAL_ADDRESS_2 >> 32) & 0xFFFFFFFF); 
													
				// knock domain 1's door to get domain 0's info (in ISR)
				DoorbellTrigger(pdx, DOMAIN_0, 0x8000); 
			}
					
			// Disable my doorbell
			DoorbellDisable(pdx, DOMAIN_1, 0x8000);
		}						
	}
#endif
#ifdef ONE_TO_ONE_MAPPING_SECOND_PAIR
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	// 1 pair 1-to-1 mapping (domain 2 <-> domain 3)
	if (pdx->iDomainNumber == DOMAIN_2) {
		// domain 3 knocked my door
		nValue = DoorbellStatus(pdx, DOMAIN_3);
			
		if ((nValue & 0x8000) == 0x8000) {

			ScratchpadRead(pdx, DOMAIN_3, 5, &nMemPhysicalAddress_Upper); 
			ScratchpadRead(pdx, DOMAIN_3, 4, &nMemPhysicalAddress_Lower); 	
			InitDAT(pdx, DOMAIN_2, DOMAIN_3, false, nMemPhysicalAddress_Upper, nMemPhysicalAddress_Lower); 

			ScratchpadRead(pdx, DOMAIN_3, 7, &nMemPhysicalAddress_Upper); 
			ScratchpadRead(pdx, DOMAIN_3, 6, &nMemPhysicalAddress_Lower); 	
			InitDAT(pdx, DOMAIN_2, DOMAIN_3, true, nMemPhysicalAddress_Upper, nMemPhysicalAddress_Lower); 
				
			//check whether i have the magic_number or not	
			ScratchpadRead(pdx, DOMAIN_3, 0, &nValue); 	

			if (nValue == MAGIC_NUMBER) {
				// clear MAGIC_NUMBER
				ScratchpadWrite(pdx, DOMAIN_3, 0, 0); 
					
				// fill my info
				ScratchpadWrite(pdx, DOMAIN_3, 4, DOMAIN_2_MEM_PHYSICAL_ADDRESS_1 & 0xFFFFFFFF); 
				ScratchpadWrite(pdx, DOMAIN_3, 5, (DOMAIN_2_MEM_PHYSICAL_ADDRESS_1 >> 32) & 0xFFFFFFFF); 
				ScratchpadWrite(pdx, DOMAIN_3, 6, DOMAIN_2_MEM_PHYSICAL_ADDRESS_2 & 0xFFFFFFFF); 
				ScratchpadWrite(pdx, DOMAIN_3, 7, (DOMAIN_2_MEM_PHYSICAL_ADDRESS_2 >> 32) & 0xFFFFFFFF); 
													
				// knock domain 1's door to get domain 0's info (in ISR)
				DoorbellTrigger(pdx, DOMAIN_2, 0x8000); 
			}
					
			// Disable my doorbell
			DoorbellDisable(pdx, DOMAIN_3, 0x8000);
		}						
	} else if (pdx->iDomainNumber == DOMAIN_3) {
		// domain 2 knocked my door
		nValue = DoorbellStatus(pdx, DOMAIN_3);
			
		if ((nValue & 0x8000) == 0x8000) {

			ScratchpadRead(pdx, DOMAIN_2, 5, &nMemPhysicalAddress_Upper); 
			ScratchpadRead(pdx, DOMAIN_2, 4, &nMemPhysicalAddress_Lower); 	
			InitDAT(pdx, DOMAIN_3, DOMAIN_2, false, nMemPhysicalAddress_Upper, nMemPhysicalAddress_Lower); 

			ScratchpadRead(pdx, DOMAIN_2, 7, &nMemPhysicalAddress_Upper); 
			ScratchpadRead(pdx, DOMAIN_2, 6, &nMemPhysicalAddress_Lower); 	
			InitDAT(pdx, DOMAIN_3, DOMAIN_2, true, nMemPhysicalAddress_Upper, nMemPhysicalAddress_Lower); 
				
			//check whether i have the magic_number or not	
			ScratchpadRead(pdx, DOMAIN_3, 0, &nValue); 	

			if (nValue == MAGIC_NUMBER) {
				// clear MAGIC_NUMBER
				ScratchpadWrite(pdx, DOMAIN_3, 0, 0); 
					
				// fill my info
				ScratchpadWrite(pdx, DOMAIN_3, 4, DOMAIN_3_MEM_PHYSICAL_ADDRESS_1 & 0xFFFFFFFF); 
				ScratchpadWrite(pdx, DOMAIN_3, 5, (DOMAIN_3_MEM_PHYSICAL_ADDRESS_1 >> 32) & 0xFFFFFFFF); 
				ScratchpadWrite(pdx, DOMAIN_3, 6, DOMAIN_3_MEM_PHYSICAL_ADDRESS_2 & 0xFFFFFFFF); 
				ScratchpadWrite(pdx, DOMAIN_3, 7, (DOMAIN_3_MEM_PHYSICAL_ADDRESS_2 >> 32) & 0xFFFFFFFF); 
													
				// knock domain 1's door to get domain 0's info (in ISR)
				DoorbellTrigger(pdx, DOMAIN_2, 0x8000); 
			}
					
			// Disable my doorbell
			DoorbellDisable(pdx, DOMAIN_3, 0x8000);
		}						
	}
#endif

#if defined(THREE_NODES_CIRCLE) || defined(FOUR_NODES_CIRCLE)
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	// circle
	// 3 nodes circle (domain 0 -> domain 1 -> domain 2 -> domain 0 -> domain 2 -> domain 1)
	// 4 nodes circle (domain 0 -> domain 1 -> domain 2 -> domain 3 -> domain 0 -> domain 3 -> domain 2 -> domain 1)

	if (pdx->iDomainNumber == DOMAIN_0) {
		// my door knocked
		nValue = DoorbellStatus(pdx, DOMAIN_0);
			
		if ((nValue & 0x8000) == 0x8000) {
		
			//check scratchpad 1
			ScratchpadRead(pdx, DOMAIN_0, 1, &nValue); 		
					
			if (nValue == 0) {

				// save next door to scratchpad 1 when reverse
#if NUM_OF_DOMAIN == 3				
				ScratchpadWrite(pdx, DOMAIN_0, 1, DOMAIN_2); 
#else 
				ScratchpadWrite(pdx, DOMAIN_0, 1, DOMAIN_3); 
#endif
				// init BAR 2 to map to domain 1's mem
				ScratchpadRead(pdx, DOMAIN_1, 5, &nMemPhysicalAddress_Upper); 
				ScratchpadRead(pdx, DOMAIN_1, 4, &nMemPhysicalAddress_Lower); 	
				InitDAT(pdx, DOMAIN_0, DOMAIN_1, false, nMemPhysicalAddress_Upper, nMemPhysicalAddress_Lower); 

				// knock domain 1's door 
				DoorbellTrigger(pdx, DOMAIN_1, 0x8000); 
			} else {
				int nNextDoor = nValue;

				// init BAR 4 to map to the mem of the nNextDoor
				ScratchpadRead(pdx, nNextDoor, 7, &nMemPhysicalAddress_Upper); 
				ScratchpadRead(pdx, nNextDoor, 6, &nMemPhysicalAddress_Lower); 	
				InitDAT(pdx, DOMAIN_0, nNextDoor, true, nMemPhysicalAddress_Upper, nMemPhysicalAddress_Lower); 

				ScratchpadWrite(pdx, DOMAIN_0, 1, 0);
				// Disable my doorbell
				DoorbellDisable(pdx, DOMAIN_0, 0x8000);
				// knock the nNextDoor 
				DoorbellTrigger(pdx, nNextDoor, 0x8000); 
			}
		}			
	} else if (pdx->iDomainNumber == DOMAIN_1) {
		//  my door knocked
		nValue = DoorbellStatus(pdx, DOMAIN_1);
			
		if ((nValue & 0x8000) == 0x8000) {
		
			//check scratchpad 1
			ScratchpadRead(pdx, DOMAIN_1, 1, &nValue); 		
					
			if (nValue == 0) {

				// save next door to scratchpad 1 when reverse
#if NUM_OF_DOMAIN == 3				
				ScratchpadWrite(pdx, DOMAIN_1, 1, DOMAIN_0); 
#else 
				ScratchpadWrite(pdx, DOMAIN_1, 1, DOMAIN_0); 
#endif
				// init BAR 2 to map to domain 1's mem
				ScratchpadRead(pdx, DOMAIN_1, 5, &nMemPhysicalAddress_Upper); 
				ScratchpadRead(pdx, DOMAIN_1, 4, &nMemPhysicalAddress_Lower); 	
				InitDAT(pdx, DOMAIN_1, DOMAIN_2, false, nMemPhysicalAddress_Upper, nMemPhysicalAddress_Lower); 

				// knock domain 2's door 
				DoorbellTrigger(pdx, DOMAIN_2, 0x8000); 
			} else {
				int nNextDoor = nValue;

				// init BAR 4 to map to the mem of the nNextDoor
				ScratchpadRead(pdx, nNextDoor, 7, &nMemPhysicalAddress_Upper); 
				ScratchpadRead(pdx, nNextDoor, 6, &nMemPhysicalAddress_Lower); 	
				InitDAT(pdx, DOMAIN_1, nNextDoor, true, nMemPhysicalAddress_Upper, nMemPhysicalAddress_Lower); 

				// Disable my doorbell
				DoorbellDisable(pdx, DOMAIN_1, 0x8000);
				// no next door, end here
				
			}
		}			
	} else if (pdx->iDomainNumber == DOMAIN_2) {
		// my door knocked
		nValue = DoorbellStatus(pdx, DOMAIN_2);
			
		if ((nValue & 0x8000) == 0x8000) {
		
			//check scratchpad 1
			ScratchpadRead(pdx, DOMAIN_2, 1, &nValue); 		
					
			if (nValue == 0) {

				// save next door to scratchpad 1 when reverse
				ScratchpadWrite(pdx, DOMAIN_2, 1, DOMAIN_1); 
				
#if NUM_OF_DOMAIN == 3	
				// init BAR 2 to map to domain 0's mem
				ScratchpadRead(pdx, DOMAIN_0, 5, &nMemPhysicalAddress_Upper); 
				ScratchpadRead(pdx, DOMAIN_0, 4, &nMemPhysicalAddress_Lower); 	
				InitDAT(pdx, DOMAIN_2, DOMAIN_0, false, nMemPhysicalAddress_Upper, nMemPhysicalAddress_Lower); 
				// knock domain 0's door 
				DoorbellTrigger(pdx, DOMAIN_0, 0x8000); 
#else
				// init BAR 2 to map to domain 3's mem
				ScratchpadRead(pdx, DOMAIN_3, 5, &nMemPhysicalAddress_Upper); 
				ScratchpadRead(pdx, DOMAIN_3, 4, &nMemPhysicalAddress_Lower); 	
				InitDAT(pdx, DOMAIN_2, DOMAIN_3, false, nMemPhysicalAddress_Upper, nMemPhysicalAddress_Lower); 
				// knock domain 3's door 
				DoorbellTrigger(pdx, DOMAIN_3, 0x8000); 
#endif

			} else {
				int nNextDoor = nValue;

				// init BAR 4 to map to the mem of the nNextDoor
				ScratchpadRead(pdx, nNextDoor, 7, &nMemPhysicalAddress_Upper); 
				ScratchpadRead(pdx, nNextDoor, 6, &nMemPhysicalAddress_Lower); 	
				InitDAT(pdx, DOMAIN_2, nNextDoor, true, nMemPhysicalAddress_Upper, nMemPhysicalAddress_Lower); 

				ScratchpadWrite(pdx, DOMAIN_2, 1, 0);
				// Disable my doorbell
				DoorbellDisable(pdx, DOMAIN_2, 0x8000);
				// knock the nNextDoor 
				DoorbellTrigger(pdx, nNextDoor, 0x8000); 
			}
		}			
	} else if (pdx->iDomainNumber == DOMAIN_3) {
		// my door knocked
		nValue = DoorbellStatus(pdx, DOMAIN_3);
			
		if ((nValue & 0x8000) == 0x8000) {
		
			//check scratchpad 1
			ScratchpadRead(pdx, DOMAIN_3, 1, &nValue); 		
					
			if (nValue == 0) {

				// save next door to scratchpad 1 when reverse
				ScratchpadWrite(pdx, DOMAIN_3, 1, DOMAIN_2); 

				// init BAR 2 to map to domain 1's mem
				ScratchpadRead(pdx, DOMAIN_0, 5, &nMemPhysicalAddress_Upper); 
				ScratchpadRead(pdx, DOMAIN_0, 4, &nMemPhysicalAddress_Lower); 	
				InitDAT(pdx, DOMAIN_3, DOMAIN_0, false, nMemPhysicalAddress_Upper, nMemPhysicalAddress_Lower); 

				// knock domain 0's door 
				DoorbellTrigger(pdx, DOMAIN_0, 0x8000); 
			} else {
				int nNextDoor = nValue;

				// init BAR 4 to map to the mem of the nNextDoor
				ScratchpadRead(pdx, nNextDoor, 7, &nMemPhysicalAddress_Upper); 
				ScratchpadRead(pdx, nNextDoor, 6, &nMemPhysicalAddress_Lower); 	
				InitDAT(pdx, DOMAIN_0, nNextDoor, true, nMemPhysicalAddress_Upper, nMemPhysicalAddress_Lower); 

				ScratchpadWrite(pdx, DOMAIN_0, 1, 0);
				// Disable my doorbell
				DoorbellDisable(pdx, DOMAIN_0, 0x8000);
				// knock the nNextDoor 
				DoorbellTrigger(pdx, nNextDoor, 0x8000); 
			}
		}			
	} 





#endif


	return IRQ_HANDLED;
}


/*===============================================================================================
    Scratchpad access functions
  ===============================================================================================*/

void ScratchpadWrite(PFDO_DEVICE_DATA pdx, int nDomain, int nIndex, unsigned int nValue) 
{
	*((unsigned int *)(pdx->xBar0VirtualAddr + GET_DOMAIN_BASE(pdx, nDomain) + 0x9E4 + nIndex * sizeof(int))) = nValue;
}

void ScratchpadRead(PFDO_DEVICE_DATA pdx, int nDomain, int nIndex, unsigned int *pnValue) 
{
	*pnValue = *((unsigned int *)(pdx->xBar0VirtualAddr + GET_DOMAIN_BASE(pdx, nDomain) + 0x9E4 + nIndex * sizeof(int)));
}

/*===============================================================================================
    Doorbell access functions
  ===============================================================================================*/

void DoorbellEnable(PFDO_DEVICE_DATA pdx, int nDomain, unsigned int nMask) 
{
    *((unsigned int *)(pdx->xBar0VirtualAddr + GET_DOMAIN_BASE(pdx, nDomain) + 0x9D0 )) = nMask;
}

void DoorbellDisable(PFDO_DEVICE_DATA pdx, int nDomain, unsigned int nMask) 
{
    *((unsigned int *)(pdx->xBar0VirtualAddr + GET_DOMAIN_BASE(pdx, nDomain) + 0x9CC )) = nMask;
}

void DoorbellTrigger(PFDO_DEVICE_DATA pdx, int nDomain, unsigned int nMask) 
{
    *((unsigned int *)(pdx->xBar0VirtualAddr + GET_DOMAIN_BASE(pdx, nDomain) + 0x9C4 )) = nMask;
}

unsigned int DoorbellStatus(PFDO_DEVICE_DATA pdx, int nDomain) 
{
	unsigned int nValue = 0;
	nValue = *((unsigned int *)(pdx->xBar0VirtualAddr + GET_DOMAIN_BASE(pdx, nDomain) + 0x9C4 ));
	return nValue;
}

/*===============================================================================================
    DAT initialization
  ===============================================================================================*/

void InitDAT(PFDO_DEVICE_DATA pdx, int nMyDomain, int nTargetDomain, bool fBAR4, unsigned int nMemPhysicalAddress_Upper, unsigned int nMemPhysicalAddress_Lower) 
{    
	U32 nValue = 0;
	U32 ulCdepDeviceNumber = 0;
	// get target domain device number
	ulCdepDeviceNumber = *((unsigned int *)(pdx->xBar0VirtualAddr + GET_DOMAIN_BASE(pdx, nTargetDomain) + 0x0A04 ));
	ulCdepDeviceNumber = ulCdepDeviceNumber & 0x000000FF;
	// fill my LUT table
	pci_read_config_dword(pdx->pdev, 0x0994 , &nValue);
	nValue &=  ~(0xFF << ((nTargetDomain % 4) * 8));
	nValue |= (ulCdepDeviceNumber & 0x000000FF) << ((nTargetDomain % 4) * 8);
	pci_write_config_dword(pdx->pdev, 0x0994, nValue);
				
	// Add req id = 0 to table
	nValue = 0x80000000;
	pci_write_config_dword(pdx->pdev, 0x924 , nValue);
	// Add real req id  to table
	nValue = (pdx->ReqID & 0x0000FFFF) | 0x80000000;
	pci_write_config_dword(pdx->pdev, 0x928 , nValue);
					
	if (fBAR4 == false) {		
		// set BAR2 to DAT mode
		pci_read_config_dword(pdx->pdev, 0xE8 , &nValue);
		nValue |= 1 << 4;	 		// DAT mode
		nValue &= ~(1 << 3);	// PreFetch disable
		nValue &= ~( 0x0000000F << 5);
		nValue |= ((nTargetDomain << 5) & ( 0x0000000F << 5));
		pci_write_config_dword(pdx->pdev, 0xE8 , nValue);

		// set BAR2 mapping address
		pci_read_config_dword(pdx->pdev, 0xE8 , &nValue);
						
		if (((nValue & 0x00000006) >> 1) == 0x2 && nMemPhysicalAddress_Upper) { // higi DWord
			pci_write_config_dword(pdx->pdev, 0x90C , nMemPhysicalAddress_Upper);
		} else {												
		    //3DW Address Space
		    nMemPhysicalAddress_Lower |= 0x00000001;	
	    }				
		pci_write_config_dword(pdx->pdev, 0x908 , nMemPhysicalAddress_Lower);
	} else {				
		// set BAR4 to DAT mode
		pci_read_config_dword(pdx->pdev, 0xF0 , &nValue);
		nValue |= 1 << 4;	 		// DAT mode
		nValue &= ~(1 << 3);	// PreFetch disable
		nValue &= ~( 0x0000000F << 5);
		nValue |= ((DOMAIN_0 << 5) & ( 0x0000000F << 5));
		pci_write_config_dword(pdx->pdev, 0xF0 , nValue);
																
		// set BAR4 mapping address
		pci_read_config_dword(pdx->pdev, 0xF0 , &nValue);
						
		if (((nValue & 0x00000006) >> 1) == 0x2 && nMemPhysicalAddress_Upper) { // higi DWord	
			pci_write_config_dword(pdx->pdev, 0x914 , nMemPhysicalAddress_Upper);
		} else {												
		    //3DW Address Space
		    nMemPhysicalAddress_Lower |= 0x00000001;	
	    }				
		pci_write_config_dword(pdx->pdev, 0x910 , nMemPhysicalAddress_Lower);
	}									
}




/*===============================================================================================*/

unsigned int g_nMajorNumber = (unsigned int)-1;
unsigned int g_nMinprNumber = 0;


static int pscgrande_probe(struct pci_dev * pdev, const struct pci_device_id * id)
{	
		int result = 0;
		PFDO_DEVICE_DATA pdx;

		unsigned int nClassCode = 0;
		unsigned int nValue = 0;
		
#if defined(THREE_NODES_CIRCLE) || defined(FOUR_NODES_CIRCLE)
		bool fAllLoaded = true;
		int index;
#endif
	
		pdx = kmalloc (sizeof(FDO_DEVICE_DATA), GFP_KERNEL);
		if (!pdx) {
				result = -ENOMEM;
				goto end;
		}
		memset(pdx, 0, (size_t)sizeof(pdx));

		printk(KERN_ALERT "%s(%d): pdx 0x%p\n", __func__, __LINE__, pdx);

		pdx->pdev = pdev;	
		pci_set_drvdata(pdev, pdx);

		pdx->Key.PciAddress = ((pdev->bus->number << 16) & 0xFFFF0000) | ((pdev->devfn << 1) & 0x0000FFF0) | (pdev->devfn & 0x00000007);
		pdx->Key.DeviceNumber = g_nDMAcount + g_nCDEPcount;

		pci_read_config_dword(pdev, 0x0A04, &nValue);
		printk(KERN_ALERT "%s(%d): 0x0A04 = %08X\n", __func__, __LINE__, nValue);
		if ((nValue & ( 1 << 19)) == 0) {
			pdx->primary = false;
			pdx->isLink = 1;
			pdx->Key.DeviceType = DEVICE_TYPE_NT_LINK;
			printk(KERN_ALERT "%s(%d): *************LINK SIDE*************\n", __func__, __LINE__);
		} else {
			pdx->primary = true;
			pdx->isLink = 0;
			pdx->Key.DeviceType = DEVICE_TYPE_NT_VIRTUAL;	
			printk(KERN_ALERT "%s(%d): *************VIRTUAL SIDE*************\n", __func__, __LINE__);
		}
		pdx->iDomainNumber = (nValue >> 12) & 0x0000000F;
		printk(KERN_ALERT "%s(%d): *************Domain number = %d\n", __func__, __LINE__, pdx->iDomainNumber);
		pdx->iMemBasedCdepIndex = pdx->iDomainNumber;

		pci_read_config_dword(pdev, PCI_CLASS_REVISION, &nClassCode);
		nClassCode >>= 8;
		
		if (pci_enable_device(pdev)) {
				printk(KERN_ALERT "%s(%d): failed pci_enable_device\n", __func__, __LINE__);
				result = -EIO;
				goto end;
		}
		
		pci_set_master(pdev);
		
		if (unlikely(pci_request_regions(pdev, PSCGRANDE_NAME))) {
				printk(KERN_ALERT "%s(%d): failed pci_request_regions\n", __func__, __LINE__);
				result = -EIO;
				goto enable_device_err;
		}

		// get bar 0 physical & virtual address
		pdx->xBar0PhysicalAddr = pci_resource_start(pdev, 0);
		if (pdx->xBar0PhysicalAddr == 0) {
				printk(KERN_ALERT "%s(%d): failed: pci_resource_start\n", __func__, __LINE__);
				result = -EIO;
				goto request_regions_err;
		} else {
				printk(KERN_ALERT "%s(%d): got pci resource: bar 0 physical address(0x%lx)\n", __func__, __LINE__, pdx->xBar0PhysicalAddr );
		}
				
		// get bar 0 virtual address and express all cdep virtual address
		pdx->xBar0Length = pci_resource_len(pdev, 0);
		if (pdx->xBar0Length != 0) {
				pdx->xBar0VirtualAddr = (unsigned long)ioremap(pdx->xBar0PhysicalAddr, pdx->xBar0Length);
				printk(KERN_ALERT "%s(%d): bar 0 physical remap to virt: 0x%lx\n", __func__, __LINE__, pdx->xBar0VirtualAddr);
				printk(KERN_ALERT "%s(%d): bar 0 length: %lu\n", __func__, __LINE__, pdx->xBar0Length);

				// tile 0
				pdx->pMemBasedCdep[0] = (pdx->xBar0VirtualAddr + 0x60000);
				pdx->pMemBasedCdep[1] = (pdx->xBar0VirtualAddr + 0x70000);
				// tile 1
				pdx->pMemBasedCdep[2] = (pdx->xBar0VirtualAddr + 0x61000);
				pdx->pMemBasedCdep[3] = (pdx->xBar0VirtualAddr + 0x71000);
				// tile 2
				pdx->pMemBasedCdep[4] = (pdx->xBar0VirtualAddr + 0x62000);
				pdx->pMemBasedCdep[5] = (pdx->xBar0VirtualAddr + 0x72000);
				// tile 3
				pdx->pMemBasedCdep[6] = (pdx->xBar0VirtualAddr + 0x63000);
				pdx->pMemBasedCdep[7] = (pdx->xBar0VirtualAddr + 0x73000);
				// tile 4
				pdx->pMemBasedCdep[8] = (pdx->xBar0VirtualAddr + 0x64000);
				pdx->pMemBasedCdep[9] = (pdx->xBar0VirtualAddr + 0x74000);
				// tile 5
				pdx->pMemBasedCdep[10] = (pdx->xBar0VirtualAddr + 0x65000);
				pdx->pMemBasedCdep[11] = (pdx->xBar0VirtualAddr + 0x75000);

		} else {
				printk(KERN_ALERT "%s(%d): failed: pci_resource_len get zero!!\n", __func__, __LINE__);
		}
		
	
		if (nClassCode == PSCGRANDE_CDEP_CLASS_ID) { 
			printk(KERN_ALERT "%s(%d): CDEP found\n", __func__, __LINE__);
			
			// get bar 2 physical & virtual address
			pdx->xBar2PhysicalAddr = pci_resource_start(pdev, 2);
			if (pdx->xBar2PhysicalAddr == 0) {
					printk(KERN_ALERT "%s(%d): failed: pci_resource_start\n", __func__, __LINE__);
					result = -EIO;
					goto request_regions_err;
			} else {
					printk(KERN_ALERT "%s(%d): got pci resource: bar 2 physical address(0x%lx)\n", __func__, __LINE__, pdx->xBar2PhysicalAddr );
			}
				
			// get bar 2 virtual address
			pdx->xBar2Length = pci_resource_len(pdev, 2);
			if (pdx->xBar2Length != 0) {
					pdx->xBar2VirtualAddr = (unsigned long)ioremap(pdx->xBar2PhysicalAddr, pdx->xBar2Length);
					printk(KERN_ALERT "%s(%d): BAR 2 physical remap to virt: 0x%lx\n", __func__, __LINE__, pdx->xBar2VirtualAddr);
					printk(KERN_ALERT "%s(%d): BAR 2 length: %lu\n", __func__, __LINE__, pdx->xBar2Length);
			} else {
					printk(KERN_ALERT "%s(%d): failed: pci_resource_len get zero!!\n", __func__, __LINE__);
			}

			// get bar 4 physical & virtual address
			pdx->xBar4PhysicalAddr = pci_resource_start(pdev, 4);
			if (pdx->xBar4PhysicalAddr == 0) {
					printk(KERN_ALERT "%s(%d): failed: pci_resource_start\n", __func__, __LINE__);
					result = -EIO;
					goto request_regions_err;
			} else {
					printk(KERN_ALERT "%s(%d): got pci resource: bar 4 physical address(0x%lx)\n", __func__, __LINE__, pdx->xBar4PhysicalAddr );
			}
				
			// get bar 4 virtual address
			pdx->xBar4Length = pci_resource_len(pdev, 4);
			if (pdx->xBar4Length != 0) {
					pdx->xBar4VirtualAddr = (unsigned long)ioremap(pdx->xBar4PhysicalAddr, pdx->xBar4Length);
					printk(KERN_ALERT "%s(%d): bar 4 physical remap to virt: 0x%lx\n", __func__, __LINE__, pdx->xBar4VirtualAddr);
					printk(KERN_ALERT "%s(%d): bar 4 length: %lu\n", __func__, __LINE__, pdx->xBar4Length);
			} else {
					printk(KERN_ALERT "%s(%d): failed: pci_resource_len get zero!!\n", __func__, __LINE__);
			}

			// get my Req ID from offset 0xA08 [0:15], write random value to that and read back
			//				
			pci_write_config_dword(pdev, 0x0A08, 0xAAAA5555); 
			nValue = 0;
			pci_read_config_dword(pdev, 0x0A08, &nValue);
			pdx->ReqID = nValue & 0x0000FFFF; 
			printk(KERN_ALERT "%s(%d): ReqID = 0x%x   nValue = 0x%x \n", __func__, __LINE__, pdx->ReqID, nValue);
			
			pdx->isDMA = false;
			pdx->nDeviceIndex = g_nCDEPcount;

			g_nCDEPcount++;
			
			// register IRQ			
			result = request_irq(pdev->irq, pscgrande_cdep_interrupt, IRQF_SHARED, PSCGRANDE_NAME, pdx);

			if (unlikely(result)) {
				printk(KERN_ALERT "%s(%d): failed: request_irq\n", __func__, __LINE__);
				goto enable_msi_error;
			} else {
				list_add_tail(&pdx->list ,&g_pDevice);
				printk(KERN_ALERT "%s(%d): request_irq succeeded. irq = %d\n", __func__, __LINE__, pdev->irq);
			}

#ifdef ONE_TO_ONE_MAPPING_FIRST_PAIR
			//////////////////////////////////////////////////////////////////////////////////////////////
			// 1 pair 1-to-1 mapping (domain 0 <-> domain 1)
			if (pdx->iDomainNumber == DOMAIN_0) {
				// in domain 0

				// get domain 1's scratchpad 0
				ScratchpadRead(pdx, DOMAIN_1, 0, &nValue);

				if (nValue != MAGIC_NUMBER) {
					
						// put magic number to domain 0's scratchpad 0
						ScratchpadWrite(pdx, DOMAIN_0, 0, MAGIC_NUMBER);						
						//enable my doorbell
						DoorbellEnable(pdx, DOMAIN_0, 0x8000);
					
				} else {

						// domain 1 driver was loaded already, put all information to my scatchpads.
						ScratchpadWrite(pdx, DOMAIN_0, 4, DOMAIN_0_MEM_PHYSICAL_ADDRESS_1 & 0xFFFFFFFF); 
						ScratchpadWrite(pdx, DOMAIN_0, 5, (DOMAIN_0_MEM_PHYSICAL_ADDRESS_1 >> 32) & 0xFFFFFFFF); 
						ScratchpadWrite(pdx, DOMAIN_0, 6, DOMAIN_0_MEM_PHYSICAL_ADDRESS_2 & 0xFFFFFFFF); 
						ScratchpadWrite(pdx, DOMAIN_0, 7, (DOMAIN_0_MEM_PHYSICAL_ADDRESS_2 >> 32) & 0xFFFFFFFF); 
						
						//enable my doorbell
						DoorbellEnable(pdx, DOMAIN_0, 0x8000);
						// knock domain 1's door to get domain 0's info (in ISR)
						DoorbellTrigger(pdx, DOMAIN_1, 0x8000); 
				}

			} else if (pdx->iDomainNumber == DOMAIN_1) {
				// in domain 1
				
				// get domain 0's scratchpad 0
				ScratchpadRead(pdx, DOMAIN_0, 0, &nValue);

				if (nValue != MAGIC_NUMBER) {
					
						// put magic number to domain 1's scratchpad 0
						ScratchpadWrite(pdx, DOMAIN_1, 0, MAGIC_NUMBER);						
						//enable my doorbell
						DoorbellEnable(pdx, DOMAIN_1, 0x8000);
					
				} else {

						// domain 0 driver was loaded already, put all information to my scatchpads.
						ScratchpadWrite(pdx, DOMAIN_1, 4, DOMAIN_1_MEM_PHYSICAL_ADDRESS_1 & 0xFFFFFFFF); 
						ScratchpadWrite(pdx, DOMAIN_1, 5, (DOMAIN_1_MEM_PHYSICAL_ADDRESS_1 >> 32) & 0xFFFFFFFF); 
						ScratchpadWrite(pdx, DOMAIN_1, 6, DOMAIN_1_MEM_PHYSICAL_ADDRESS_2 & 0xFFFFFFFF); 
						ScratchpadWrite(pdx, DOMAIN_1, 7, (DOMAIN_1_MEM_PHYSICAL_ADDRESS_2 >> 32) & 0xFFFFFFFF); 


						//enable my doorbell
						DoorbellEnable(pdx, DOMAIN_1, 0x8000);
						// knock domain 0's door to get domain 0's info (in ISR)
						DoorbellTrigger(pdx, DOMAIN_0, 0x8000); 
				}
			}
#endif
#ifdef ONE_TO_ONE_MAPPING_SECOND_PAIR
			//////////////////////////////////////////////////////////////////////////////////////////////
			// 1 pair 1-to-1 mapping (domain 2 <-> domain 3)
			if (pdx->iDomainNumber == DOMAIN_2) {
				// in domain 2

				// get domain 3's scratchpad 0
				ScratchpadRead(pdx, DOMAIN_3, 0, &nValue);

				if (nValue != MAGIC_NUMBER) {
					
						// put magic number to domain 2's scratchpad 0
						ScratchpadWrite(pdx, DOMAIN_2, 0, MAGIC_NUMBER);						
						//enable my doorbell
						DoorbellEnable(pdx, DOMAIN_2, 0x8000);
					
				} else {

						// domain 1 driver was loaded already, put all information to my scatchpads.
						ScratchpadWrite(pdx, DOMAIN_2, 4, DOMAIN_2_MEM_PHYSICAL_ADDRESS_1 & 0xFFFFFFFF); 
						ScratchpadWrite(pdx, DOMAIN_2, 5, (DOMAIN_2_MEM_PHYSICAL_ADDRESS_1 >> 32) & 0xFFFFFFFF); 
						ScratchpadWrite(pdx, DOMAIN_2, 6, DOMAIN_2_MEM_PHYSICAL_ADDRESS_2 & 0xFFFFFFFF); 
						ScratchpadWrite(pdx, DOMAIN_2, 7, (DOMAIN_2_MEM_PHYSICAL_ADDRESS_2 >> 32) & 0xFFFFFFFF); 
						
						//enable my doorbell
						DoorbellEnable(pdx, DOMAIN_2, 0x8000);
						// knock domain 3's door to get domain 2's info (in ISR)
						DoorbellTrigger(pdx, DOMAIN_3, 0x8000); 
				}

			} else if (pdx->iDomainNumber == DOMAIN_3) {
				// in domain 3
				
				// get domain 2's scratchpad 0
				ScratchpadRead(pdx, DOMAIN_2, 0, &nValue);

				if (nValue != MAGIC_NUMBER) {
					
						// put magic number to domain 3's scratchpad 0
						ScratchpadWrite(pdx, DOMAIN_3, 0, MAGIC_NUMBER);						
						//enable my doorbell
						DoorbellEnable(pdx, DOMAIN_3, 0x8000);
					
				} else {

						// domain 2 driver was loaded already, put all information to my scatchpads.
						ScratchpadWrite(pdx, DOMAIN_3, 4, DOMAIN_3_MEM_PHYSICAL_ADDRESS_1 & 0xFFFFFFFF); 
						ScratchpadWrite(pdx, DOMAIN_3, 5, (DOMAIN_3_MEM_PHYSICAL_ADDRESS_1 >> 32) & 0xFFFFFFFF); 
						ScratchpadWrite(pdx, DOMAIN_3, 6, DOMAIN_3_MEM_PHYSICAL_ADDRESS_2 & 0xFFFFFFFF); 
						ScratchpadWrite(pdx, DOMAIN_3, 7, (DOMAIN_3_MEM_PHYSICAL_ADDRESS_2 >> 32) & 0xFFFFFFFF); 


						//enable my doorbell
						DoorbellEnable(pdx, DOMAIN_3, 0x8000);
						// knock domain 2's door to get domain 3's info (in ISR)
						DoorbellTrigger(pdx, DOMAIN_2, 0x8000); 
				}
			}

#endif

			


#if defined(THREE_NODES_CIRCLE) || defined(FOUR_NODES_CIRCLE)
			//////////////////////////////////////////////////////////////////////////////////////////////
			// 3 nodes circle (domain 0 -> domain 1 -> domain 2 -> domain 0 -> domain 2 -> domain 1)
			// 4 nodes circle (domain 0 -> domain 1 -> domain 2 -> domain 3 -> domain 0 -> domain 3 -> domain 2 -> domain 1)

			for (index = 0; index < NUM_OF_DOMAIN; index++) {
				if (pdx->iDomainNumber == index)
					continue;
				
				ScratchpadRead(pdx, index, 0, &nValue);

				if (nValue != MAGIC_NUMBER) {
					fAllLoaded = false;
					break;
				}
			}


			switch (pdx->iDomainNumber) {
			case DOMAIN_0:
				// put all information to my scatchpads.
				ScratchpadWrite(pdx, DOMAIN_0, 4, DOMAIN_0_MEM_PHYSICAL_ADDRESS_1 & 0xFFFFFFFF); 
				ScratchpadWrite(pdx, DOMAIN_0, 5, (DOMAIN_0_MEM_PHYSICAL_ADDRESS_1 >> 32) & 0xFFFFFFFF); 
				ScratchpadWrite(pdx, DOMAIN_0, 6, DOMAIN_0_MEM_PHYSICAL_ADDRESS_2 & 0xFFFFFFFF); 
				ScratchpadWrite(pdx, DOMAIN_0, 7, (DOMAIN_0_MEM_PHYSICAL_ADDRESS_2 >> 32) & 0xFFFFFFFF); 
				ScratchpadWrite(pdx, DOMAIN_0, 0, 0); 
				break;
			case DOMAIN_1:
				// put all information to my scatchpads.
				ScratchpadWrite(pdx, DOMAIN_1, 4, DOMAIN_1_MEM_PHYSICAL_ADDRESS_1 & 0xFFFFFFFF); 
				ScratchpadWrite(pdx, DOMAIN_1, 5, (DOMAIN_1_MEM_PHYSICAL_ADDRESS_1 >> 32) & 0xFFFFFFFF); 
				ScratchpadWrite(pdx, DOMAIN_1, 6, DOMAIN_1_MEM_PHYSICAL_ADDRESS_2 & 0xFFFFFFFF); 
				ScratchpadWrite(pdx, DOMAIN_1, 7, (DOMAIN_1_MEM_PHYSICAL_ADDRESS_2 >> 32) & 0xFFFFFFFF); 
				ScratchpadWrite(pdx, DOMAIN_1, 0, 0); 
				break;
			case DOMAIN_2:
				// put all information to my scatchpads.
				ScratchpadWrite(pdx, DOMAIN_2, 4, DOMAIN_2_MEM_PHYSICAL_ADDRESS_1 & 0xFFFFFFFF); 
				ScratchpadWrite(pdx, DOMAIN_2, 5, (DOMAIN_2_MEM_PHYSICAL_ADDRESS_1 >> 32) & 0xFFFFFFFF); 
				ScratchpadWrite(pdx, DOMAIN_2, 6, DOMAIN_2_MEM_PHYSICAL_ADDRESS_2 & 0xFFFFFFFF); 
				ScratchpadWrite(pdx, DOMAIN_2, 7, (DOMAIN_2_MEM_PHYSICAL_ADDRESS_2 >> 32) & 0xFFFFFFFF); 
				ScratchpadWrite(pdx, DOMAIN_2, 0, 0); 
				break;
			case DOMAIN_3:
				// put all information to my scatchpads.
				ScratchpadWrite(pdx, DOMAIN_3, 4, DOMAIN_3_MEM_PHYSICAL_ADDRESS_1 & 0xFFFFFFFF); 
				ScratchpadWrite(pdx, DOMAIN_3, 5, (DOMAIN_3_MEM_PHYSICAL_ADDRESS_1 >> 32) & 0xFFFFFFFF); 
				ScratchpadWrite(pdx, DOMAIN_3, 6, DOMAIN_3_MEM_PHYSICAL_ADDRESS_2 & 0xFFFFFFFF); 
				ScratchpadWrite(pdx, DOMAIN_3, 7, (DOMAIN_3_MEM_PHYSICAL_ADDRESS_2 >> 32) & 0xFFFFFFFF); 
				ScratchpadWrite(pdx, DOMAIN_3, 0, 0); 
				break;

			}
			
			// put magic number to my scratchpad 0
			ScratchpadWrite(pdx, pdx->iDomainNumber, 0, MAGIC_NUMBER);
			//enable my doorbell
			DoorbellEnable(pdx, pdx->iDomainNumber, 0x8000);

			if (fAllLoaded) {
				
				// knock domain 0's door to get domain 0's info (in ISR)
				DoorbellTrigger(pdx, DOMAIN_0, 0x8000); 
			}



#endif


			//////////////////////////////////////////////////////////////////////////////////////////////





		}


		goto end;
		
enable_msi_error:
		iounmap((void*)pdx->xBar0VirtualAddr );
request_regions_err:
		pci_release_regions(pdev);
enable_device_err:
		pci_disable_device(pdev);
end:
		if (result < 0) {		
				kfree(pdx);
		}

		return result; 
}

/*static*/ void pscgrande_remove(struct pci_dev * pdev)
{
	PFDO_DEVICE_DATA pdx = (PFDO_DEVICE_DATA)pci_get_drvdata(pdev);
	printk( KERN_NOTICE "pscgrande: pscgrande_remove" );

	
	free_irq(pdev->irq, pdx->pdev);
	//pci_disable_msi(pdev);
		
	iounmap((void*)pdx->xBar0VirtualAddr );
	pci_release_regions(pdev);
	pci_disable_device(pdev);

	kfree(pdx);

}

/*===============================================================================================*/
static struct pci_device_id pscgrande_ids[] = {	
	{ PSCGRANDE_VENDOR_ID, PSCGRANDE_DEVICE_ID, PCI_ANY_ID, PCI_ANY_ID, PSCGRANDE_CDEP_CLASS_ID, PSCGRANDE_CLASS_MASK },	
	{0,}
};
MODULE_DEVICE_TABLE(pci, pscgrande_ids);


/*static*/ struct pci_driver pscgrande_driver = {
		.name 		= PSCGRANDE_NAME,
		.id_table 	= pscgrande_ids,
		.probe 		= pscgrande_probe,
		.remove 	= pscgrande_remove,
};




/*static*/ int pscgrande_init(void)
{
		int result = 0;
    
		PFDO_DEVICE_DATA pdx;
		struct list_head *pos;

		printk( KERN_NOTICE "pscgrande: Initialization started\n" );
		printk( KERN_NOTICE "pscgrande: Version " PSCGRANDE_VERSION "\n");
 		
		result = pci_register_driver(&pscgrande_driver);
		if (result < 0) {
				printk("failed: pci_register_driver\n");
				return result;
		}
				
	printk( KERN_NOTICE "pscgrande: Class created" );

	g_ppscgrande_class = class_create(THIS_MODULE, PSCGRANDE_NAME);


	result = alloc_chrdev_region(&xDeviceNo, 0, g_nDMAcount + g_nCDEPcount, PSCGRANDE_CDEP_DEVICE_NAME);  
	if (result < 0) {
		printk(KERN_ALERT "%s(%d): alloc_chrdev_region.\n", __func__, __LINE__);
		return result;
	}
	g_nMajorNumber = MAJOR(xDeviceNo);



	list_for_each(pos, &g_pDevice) {
		pdx = (PFDO_DEVICE_DATA)pos;
		printk( KERN_NOTICE "pscgrande: alloc %p", pdx );
		pdx->xDeviceNo = MKDEV(g_nMajorNumber, pdx->nDeviceIndex  + (pdx->isDMA == true ? 0 : g_nDMAcount) );

		
		cdev_init(&pdx->chr_dev, &pscgrande_cdep_fops);
		result = cdev_add(&pdx->chr_dev, pdx->xDeviceNo, 1);
		if (result < 0) {
			printk(KERN_ALERT "%s(%d): cdev_add fail.\n", __func__, __LINE__);
			return result;
		}		
		sprintf(pdx->devname, "CDEP_%d", pdx->nDeviceIndex);
		pdx->pdevice = device_create(g_ppscgrande_class, NULL, pdx->xDeviceNo, NULL , pdx->devname);	
		
	}  

		
    	return result;
}
/*-----------------------------------------------------------------------------------------------*/
/*static*/ void pscgrande_exit(void)
{
   	printk( KERN_NOTICE "pscgrande: Exiting" );
	
	while (list_empty(&g_pDevice) == false) {
		PFDO_DEVICE_DATA pdx = (PFDO_DEVICE_DATA)g_pDevice.next;			
		printk( KERN_NOTICE "pscgrande: free %p", pdx );	
		device_destroy(g_ppscgrande_class , pdx->xDeviceNo);
		cdev_del(&pdx->chr_dev);			
		list_del((struct list_head*)&pdx->list);		
	}
		
	unregister_chrdev_region(xDeviceNo, g_nDMAcount + g_nCDEPcount);

	class_destroy(g_ppscgrande_class);
		
	pci_unregister_driver(&pscgrande_driver);

}
/*===============================================================================================*/

module_init(pscgrande_init);
module_exit(pscgrande_exit);
